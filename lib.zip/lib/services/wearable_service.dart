import 'package:test_steps/services/bluetooth_watch_service.dart';
import 'package:test_steps/services/health_service.dart';
import 'package:test_steps/services/supabase_service.dart';

class WearableService {
  WearableService(
    this._supabaseService, {
    HealthService? healthService,
    BluetoothWatchService? bluetoothWatchService,
  }) : _healthService = healthService ?? HealthService(),
       _bluetoothWatchService =
           bluetoothWatchService ?? BluetoothWatchService();

  final SupabaseService _supabaseService;
  final HealthService _healthService;
  final BluetoothWatchService _bluetoothWatchService;

  Future<List<WatchDevice>> scanForWatches() {
    return _bluetoothWatchService.scanForWatches();
  }

  Future<WatchConnectionResult> connectBluetooth(String deviceId) {
    return _bluetoothWatchService.connect(deviceId);
  }

  Future<HealthStepResult> fetchSteps({required int fallbackSteps}) {
    return _healthService.readTodaySteps(fallbackSteps: fallbackSteps);
  }

  Future<void> pushStepsToSupabase(int steps) async {
    final result = await _supabaseService.syncDailyStepCount(steps);
    if (result['success'] != true) {
      throw Exception(result['error']?.toString() ?? 'Step sync failed');
    }
  }

  Future<WearableSyncResult> connectAndSync({
    required int fallbackSteps,
    String? deviceId,
  }) async {
    WatchConnectionResult? connectionResult;
    if (deviceId != null && deviceId.isNotEmpty) {
      connectionResult = await connectBluetooth(deviceId);
    }

    final healthResult = await fetchSteps(fallbackSteps: fallbackSteps);
    await pushStepsToSupabase(healthResult.steps);

    return WearableSyncResult(
      steps: healthResult.steps,
      syncedAt: DateTime.now(),
      source: healthResult.source,
      connectedDevice: connectionResult?.device,
      bluetoothServiceIds: connectionResult?.serviceIds ?? const [],
    );
  }
}

class WearableSyncResult {
  const WearableSyncResult({
    required this.steps,
    required this.syncedAt,
    required this.source,
    this.connectedDevice,
    this.bluetoothServiceIds = const [],
  });

  final int steps;
  final DateTime syncedAt;
  final String source;
  final WatchDevice? connectedDevice;
  final List<String> bluetoothServiceIds;
}
