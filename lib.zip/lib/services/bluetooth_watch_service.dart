import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class BluetoothWatchService {
  final Map<String, BluetoothDevice> _devicesById = {};

  Future<List<WatchDevice>> scanForWatches({
    Duration timeout = const Duration(seconds: 8),
  }) async {
    if (kIsWeb || (!Platform.isIOS && !Platform.isAndroid)) return [];

    await _requestBluetoothPermissions();
    await _ensureBluetoothIsOn();

    final results = <String, WatchDevice>{};
    final subscription = FlutterBluePlus.scanResults.listen((scanResults) {
      for (final result in scanResults) {
        final device = result.device;
        final id = device.remoteId.str;
        _devicesById[id] = device;

        final name = _deviceName(device, result.advertisementData.advName);
        if (name.trim().isEmpty) continue;

        results[id] = WatchDevice(
          id: id,
          name: name,
          rssi: result.rssi,
          isLikelyWatch: _looksLikeWatch(name),
        );
      }
    });

    try {
      await FlutterBluePlus.startScan(
        timeout: timeout,
        webOptionalServices: [Guid('1800'), Guid('180a'), Guid('180f')],
      );
      await Future<void>.delayed(timeout + const Duration(milliseconds: 350));
    } finally {
      await FlutterBluePlus.stopScan();
      await subscription.cancel();
    }

    final devices = results.values.toList()
      ..sort((a, b) {
        if (a.isLikelyWatch != b.isLikelyWatch) {
          return a.isLikelyWatch ? -1 : 1;
        }
        return b.rssi.compareTo(a.rssi);
      });
    return devices;
  }

  Future<WatchConnectionResult> connect(String deviceId) async {
    if (kIsWeb || (!Platform.isIOS && !Platform.isAndroid)) {
      throw Exception(
        'Bluetooth watch connection is only available on mobile.',
      );
    }

    await _requestBluetoothPermissions();
    await _ensureBluetoothIsOn();

    final device = _devicesById[deviceId] ?? BluetoothDevice.fromId(deviceId);
    await device.connect(timeout: const Duration(seconds: 15), mtu: null);
    final services = await device.discoverServices();

    final serviceIds = services.map((service) => service.uuid.str).toList();
    return WatchConnectionResult(
      device: WatchDevice(
        id: device.remoteId.str,
        name: _deviceName(device, device.advName),
        rssi: 0,
        isLikelyWatch: _looksLikeWatch(_deviceName(device, device.advName)),
      ),
      serviceIds: serviceIds,
      connectedAt: DateTime.now(),
    );
  }

  Future<void> _requestBluetoothPermissions() async {
    if (Platform.isAndroid) {
      final scan = await Permission.bluetoothScan.request();
      final connect = await Permission.bluetoothConnect.request();
      if (!scan.isGranted || !connect.isGranted) {
        throw Exception('Bluetooth permission is required to connect a watch.');
      }
      return;
    }

    if (Platform.isIOS) {
      final bluetooth = await Permission.bluetooth.request();
      if (!bluetooth.isGranted && !bluetooth.isLimited) {
        throw Exception('Bluetooth permission is required to connect a watch.');
      }
    }
  }

  Future<void> _ensureBluetoothIsOn() async {
    final state = await FlutterBluePlus.adapterState.first;
    if (state == BluetoothAdapterState.on) return;

    if (Platform.isAndroid) {
      await FlutterBluePlus.turnOn(timeout: 10);
      final nextState = await FlutterBluePlus.adapterState.first;
      if (nextState == BluetoothAdapterState.on) return;
    }

    throw Exception('Turn on Bluetooth to connect your watch.');
  }

  String _deviceName(BluetoothDevice device, String advertisedName) {
    if (advertisedName.trim().isNotEmpty) {
      return advertisedName.trim();
    }
    if (device.platformName.trim().isNotEmpty) {
      return device.platformName.trim();
    }
    return 'Unknown wearable';
  }

  bool _looksLikeWatch(String name) {
    final normalized = name.toLowerCase();
    return normalized.contains('watch') ||
        normalized.contains('wear') ||
        normalized.contains('fitbit') ||
        normalized.contains('garmin') ||
        normalized.contains('amazfit') ||
        normalized.contains('huawei') ||
        normalized.contains('galaxy');
  }
}

class WatchDevice {
  const WatchDevice({
    required this.id,
    required this.name,
    required this.rssi,
    required this.isLikelyWatch,
  });

  final String id;
  final String name;
  final int rssi;
  final bool isLikelyWatch;
}

class WatchConnectionResult {
  const WatchConnectionResult({
    required this.device,
    required this.serviceIds,
    required this.connectedAt,
  });

  final WatchDevice device;
  final List<String> serviceIds;
  final DateTime connectedAt;
}
