import 'dart:async';

import 'package:riverpod/legacy.dart';
import 'package:test_steps/services/bluetooth_watch_service.dart';
import 'package:test_steps/services/supabase_service.dart';
import 'package:test_steps/services/wearable_service.dart';

enum WearableSyncStage {
  idle,
  scanning,
  connectingBluetooth,
  requestingAccess,
  readingSteps,
  updatingDashboard,
  connected,
  failed,
}

class WearableState {
  const WearableState({
    this.isConnecting = false,
    this.isConnected = false,
    this.progress = 0,
    this.syncedSteps = 0,
    this.stage = WearableSyncStage.idle,
    this.error,
    this.syncedAt,
    this.devices = const [],
    this.selectedDeviceId,
    this.isScanning = false,
    this.connectedDevice,
    this.healthSource,
  });

  final bool isConnecting;
  final bool isConnected;
  final bool isScanning;
  final double progress;
  final int syncedSteps;
  final WearableSyncStage stage;
  final String? error;
  final DateTime? syncedAt;
  final List<WatchDevice> devices;
  final String? selectedDeviceId;
  final WatchDevice? connectedDevice;
  final String? healthSource;

  WearableState copyWith({
    bool? isConnecting,
    bool? isConnected,
    bool? isScanning,
    double? progress,
    int? syncedSteps,
    WearableSyncStage? stage,
    String? error,
    bool clearError = false,
    DateTime? syncedAt,
    List<WatchDevice>? devices,
    String? selectedDeviceId,
    bool clearSelectedDevice = false,
    WatchDevice? connectedDevice,
    String? healthSource,
  }) {
    return WearableState(
      isConnecting: isConnecting ?? this.isConnecting,
      isConnected: isConnected ?? this.isConnected,
      isScanning: isScanning ?? this.isScanning,
      progress: progress ?? this.progress,
      syncedSteps: syncedSteps ?? this.syncedSteps,
      stage: stage ?? this.stage,
      error: clearError ? null : error ?? this.error,
      syncedAt: syncedAt ?? this.syncedAt,
      devices: devices ?? this.devices,
      selectedDeviceId: clearSelectedDevice
          ? null
          : selectedDeviceId ?? this.selectedDeviceId,
      connectedDevice: connectedDevice ?? this.connectedDevice,
      healthSource: healthSource ?? this.healthSource,
    );
  }
}

class WearableNotifier extends StateNotifier<WearableState> {
  WearableNotifier(this._service) : super(const WearableState());

  final WearableService _service;
  Timer? _progressTimer;

  Future<void> scanForWatches() async {
    if (state.isScanning || state.isConnecting) return;

    state = state.copyWith(
      isScanning: true,
      stage: WearableSyncStage.scanning,
      clearError: true,
    );

    try {
      final devices = await _service.scanForWatches();
      state = state.copyWith(
        isScanning: false,
        stage: WearableSyncStage.idle,
        devices: devices,
        selectedDeviceId: devices.isNotEmpty ? devices.first.id : null,
      );
    } catch (e) {
      state = state.copyWith(
        isScanning: false,
        stage: WearableSyncStage.failed,
        error: e.toString(),
      );
    }
  }

  void selectDevice(String deviceId) {
    state = state.copyWith(selectedDeviceId: deviceId, clearError: true);
  }

  Future<void> connectAndSync({
    required int currentSteps,
    String? deviceId,
  }) async {
    if (state.isConnecting) return;

    _startProgress();
    final resolvedDeviceId =
        (deviceId != null && deviceId.isNotEmpty) ? deviceId : null;
    state = WearableState(
      isConnecting: true,
      progress: 0.08,
      syncedSteps: currentSteps,
      stage: resolvedDeviceId != null
          ? WearableSyncStage.connectingBluetooth
          : WearableSyncStage.requestingAccess,
      devices: state.devices,
      selectedDeviceId: state.selectedDeviceId,
    );

    try {
      WatchConnectionResult? connectionResult;
      if (resolvedDeviceId != null) {
        connectionResult = await _service.connectBluetooth(resolvedDeviceId);
      }

      state = state.copyWith(stage: WearableSyncStage.requestingAccess);
      final healthResult = await _service.fetchSteps(
        fallbackSteps: currentSteps,
      );

      state = state.copyWith(
        stage: WearableSyncStage.updatingDashboard,
        syncedSteps: healthResult.steps,
      );
      await _service.pushStepsToSupabase(healthResult.steps);

      _stopProgress();
      state = state.copyWith(
        isConnecting: false,
        isConnected: true,
        progress: 1,
        syncedSteps: healthResult.steps,
        stage: WearableSyncStage.connected,
        syncedAt: DateTime.now(),
        connectedDevice: connectionResult?.device,
        healthSource: healthResult.source,
        clearError: true,
      );
    } catch (e) {
      _stopProgress();
      state = state.copyWith(
        isConnecting: false,
        isConnected: false,
        progress: 0,
        stage: WearableSyncStage.failed,
        error: e.toString(),
      );
    }
  }

  void _startProgress() {
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(milliseconds: 380), (_) {
      if (!state.isConnecting) return;
      final nextProgress = (state.progress + 0.08).clamp(0.08, 0.92);
      state = state.copyWith(progress: nextProgress);
    });
  }

  void _stopProgress() {
    _progressTimer?.cancel();
    _progressTimer = null;
  }

  @override
  void dispose() {
    _stopProgress();
    super.dispose();
  }
}

final wearableProvider = StateNotifierProvider<WearableNotifier, WearableState>(
  (ref) {
    return WearableNotifier(WearableService(SupabaseService()));
  },
);
