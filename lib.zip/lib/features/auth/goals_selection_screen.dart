import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:test_steps/core/theme/app_colors.dart';
import 'package:test_steps/core/theme/app_text_styles.dart';
import 'package:test_steps/providers/auth_provider.dart';
import 'package:test_steps/screens/main_navigation.dart';
import 'package:test_steps/widgets/shared/app_borders.dart';
import 'package:test_steps/widgets/shared/app_circular_back_button.dart';
import 'package:test_steps/widgets/shared/primary_button.dart';

class GoalsSelectionScreen extends ConsumerWidget {
  const GoalsSelectionScreen({super.key});

  static const _weightGoals = ['Lose Weight', 'Maintain Weight', 'Gain Weight'];

  static const _dailyStepGoals = [5000, 8000, 10000, 12000, 15000];

  Future<void> _finishProfile(BuildContext context, WidgetRef ref) async {
    final result = await ref
        .read(authProvider.notifier)
        .saveOnboardingProfile();
    if (!context.mounted) return;

    if (result.success) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const MainNavigation()),
        (route) => false,
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(result.error ?? 'Failed to save profile.'),
        backgroundColor: AppColors.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authProvider);
    final authNotifier = ref.read(authProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      body: Stack(
        children: [
          IgnorePointer(
            child: Image.asset(
              'assets/images/back.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: 260.h,
              color: AppColors.surface.withValues(alpha: 0.7),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: AppCircularBackButton(),
                  ),
                  130.verticalSpace,
                  Text(
                    'Set Your Goals?',
                    textAlign: TextAlign.center,
                    style: AppTextStyles.montserrat(
                      size: 24.sp,
                      color: AppColors.textPrimary,
                      weight: FontWeight.w800,
                    ),
                  ),
                  32.verticalSpace,
                  _SectionTitle(label: 'Weight Goal'),
                  12.verticalSpace,
                  ..._weightGoals.map((goal) {
                    return Padding(
                      padding: EdgeInsets.only(bottom: 18.h),
                      child: _WeightGoalOption(
                        label: goal,
                        selected: authState.selectedWeightGoal == goal,
                        onTap: () => authNotifier.setWeightGoal(goal),
                      ),
                    );
                  }),
                  12.verticalSpace,
                  _SectionTitle(label: 'Daily Steps Goal'),
                  14.verticalSpace,
                  Wrap(
                    spacing: 10.w,
                    runSpacing: 12.h,
                    children: _dailyStepGoals.map((stepsGoal) {
                      return _DailyStepsGoalChip(
                        stepsGoal: stepsGoal,
                        selected: authState.selectedDailyStepsGoal == stepsGoal,
                        onTap: () => authNotifier.setDailyStepsGoal(stepsGoal),
                      );
                    }).toList(),
                  ),
                  const Spacer(),
                  PrimaryButton(
                    label: authState.isProfileSaving
                        ? 'Saving...'
                        : 'Finish Profile',
                    isLoading: authState.isProfileSaving,
                    onTap: authState.isProfileSaving
                        ? null
                        : () => _finishProfile(context, ref),
                  ),
                  28.verticalSpace,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: AppTextStyles.montserrat(
        size: 17.sp,
        color: AppColors.textPrimary,
        weight: FontWeight.w800,
      ),
    );
  }
}

class _WeightGoalOption extends StatelessWidget {
  const _WeightGoalOption({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 48.h,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(18.r),
          border: AppBorders.raised(
            color: selected ? AppColors.splashBlue : AppColors.borderColor,
          ),
        ),
        child: Text(
          label,
          style: AppTextStyles.montserrat(
            size: 15.sp,
            color: AppColors.textPrimary,
            weight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _DailyStepsGoalChip extends StatelessWidget {
  const _DailyStepsGoalChip({
    required this.stepsGoal,
    required this.selected,
    required this.onTap,
  });

  final int stepsGoal;
  final bool selected;
  final VoidCallback onTap;

  String get _label => stepsGoal.toString().replaceAllMapped(
    RegExp(r'(\d)(?=(\d{3})+$)'),
    (match) => '${match[1]},',
  );

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 90.w,
        height: 48.h,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16.r),
          border: AppBorders.raised(
            color: selected ? AppColors.splashBlue : AppColors.borderColor,
          ),
        ),
        child: Text(
          _label,
          style: AppTextStyles.montserrat(
            size: 15.sp,
            color: AppColors.textPrimary,
            weight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
