import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:test_steps/core/theme/app_colors.dart';
import 'package:test_steps/core/theme/app_text_styles.dart';
import 'package:test_steps/providers/wearable_provider.dart';
import 'package:test_steps/services/bluetooth_watch_service.dart';
import 'package:test_steps/services/dashboard_service.dart';
import 'package:test_steps/widgets/shared/app_borders.dart';
import 'package:test_steps/widgets/shared/app_circular_back_button.dart';
import 'package:test_steps/widgets/shared/primary_button.dart';

class WearableSyncScreen extends ConsumerStatefulWidget {
  const WearableSyncScreen({super.key, required this.currentSteps});

  final int currentSteps;

  @override
  ConsumerState<WearableSyncScreen> createState() => _WearableSyncScreenState();
}

class _WearableSyncScreenState extends ConsumerState<WearableSyncScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(wearableProvider.notifier).scanForWatches();
    });
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<WearableState>(wearableProvider, (previous, next) {
      if (previous?.isConnected != true && next.isConnected) {
        ref.read(dashboardProvider.notifier).loadDashboard(force: true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Steps synced — ${_formatCount(next.syncedSteps)} steps updated.',
            ),
            behavior: SnackBarBehavior.floating,
            backgroundColor: AppColors.success,
          ),
        );
      }
    });

    final wearableState = ref.watch(wearableProvider);
    final stepsLabel = _formatCount(
      wearableState.syncedSteps > 0
          ? wearableState.syncedSteps
          : widget.currentSteps,
    );

    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      body: Stack(
        children: [
          IgnorePointer(
            child: Image.asset(
              'assets/images/back.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: 260.h,
              color: AppColors.surface.withValues(alpha: 0.72),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 18.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const AppCircularBackButton(),
                        24.verticalSpace,
                        Text(
                          'Connect Wearable',
                          style: AppTextStyles.montserrat(
                            size: 26.sp,
                            color: AppColors.textPrimary,
                            weight: FontWeight.w800,
                          ),
                        ),
                        8.verticalSpace,
                        Text(
                          'Sync your watch to keep today\'s steps and energy updated.',
                          style: AppTextStyles.montserrat(
                            size: 14.sp,
                            color: AppColors.textSecondary,
                            weight: FontWeight.w400,
                            height: 1.45,
                          ),
                        ),
                        24.verticalSpace,
                        _WearableSyncCard(
                          progress: wearableState.progress,
                          connected: wearableState.isConnected,
                          stepsLabel: stepsLabel,
                          deviceName:
                              wearableState.connectedDevice?.name ??
                              _selectedDeviceName(wearableState),
                        ),
                        16.verticalSpace,
                        _DevicePickerCard(
                          devices: wearableState.devices,
                          selectedDeviceId: wearableState.selectedDeviceId,
                          isScanning: wearableState.isScanning,
                          onSelect: ref
                              .read(wearableProvider.notifier)
                              .selectDevice,
                          onScan: ref
                              .read(wearableProvider.notifier)
                              .scanForWatches,
                        ),
                        16.verticalSpace,
                        _SyncStatusList(stage: wearableState.stage),
                        if (wearableState.error != null) ...[
                          12.verticalSpace,
                          _WearableErrorBanner(message: wearableState.error!),
                        ],
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(16.w, 8.h, 16.w, 16.h),
                  child: PrimaryButton(
                    label: wearableState.isConnected
                        ? 'Sync Again'
                        : wearableState.stage == WearableSyncStage.failed
                        ? 'Try Again'
                        : 'Connect & Sync',
                    isLoading: wearableState.isConnecting,
                    onTap: wearableState.isConnecting
                        ? null
                        : () => ref
                              .read(wearableProvider.notifier)
                              .connectAndSync(
                                currentSteps: widget.currentSteps,
                                deviceId: wearableState.selectedDeviceId,
                              ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String? _selectedDeviceName(WearableState state) {
    final selectedDeviceId = state.selectedDeviceId;
    if (selectedDeviceId == null) return null;
    for (final device in state.devices) {
      if (device.id == selectedDeviceId) return device.name;
    }
    return null;
  }

  String _formatCount(int value) {
    return value.toString().replaceAllMapped(
      RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
      (match) => '${match[1]},',
    );
  }
}

class _WearableSyncCard extends StatelessWidget {
  const _WearableSyncCard({
    required this.progress,
    required this.connected,
    required this.stepsLabel,
    this.deviceName,
  });

  final double progress;
  final bool connected;
  final String stepsLabel;
  final String? deviceName;

  @override
  Widget build(BuildContext context) {
    final percent = (progress * 100).round();

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(18.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24.r),
        border: AppBorders.raised(),
      ),
      child: Column(
        children: [
          Container(
            width: 86.w,
            height: 86.w,
            decoration: BoxDecoration(
              color: connected
                  ? const Color(0xFFE8FBEF)
                  : const Color(0xFFEAF1FF),
              shape: BoxShape.circle,
            ),
            child: Icon(
              connected ? Icons.watch_rounded : Icons.watch_outlined,
              size: 44.sp,
              color: connected ? AppColors.success : AppColors.blueColor,
            ),
          ),
          18.verticalSpace,
          Text(
            connected ? 'Watch Connected' : 'Ready to connect',
            style: AppTextStyles.montserrat(
              size: 18.sp,
              color: AppColors.textPrimary,
              weight: FontWeight.w800,
            ),
          ),
          8.verticalSpace,
          Text(
            deviceName == null
                ? '$stepsLabel steps from Health'
                : '$stepsLabel steps from Health via $deviceName',
            style: AppTextStyles.montserrat(
              size: 14.sp,
              color: AppColors.textSecondary,
              weight: FontWeight.w500,
            ),
          ),
          18.verticalSpace,
          LayoutBuilder(
            builder: (context, constraints) {
              return Stack(
                children: [
                  Container(
                    height: 8.h,
                    decoration: BoxDecoration(
                      color: AppColors.borderColor,
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    width: constraints.maxWidth * progress,
                    height: 8.h,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF5169FF), Color(0xFF53E4F3)],
                      ),
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                ],
              );
            },
          ),
          10.verticalSpace,
          Text(
            '$percent%',
            style: AppTextStyles.montserrat(
              size: 13.sp,
              color: AppColors.textPrimary,
              weight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _DevicePickerCard extends StatelessWidget {
  const _DevicePickerCard({
    required this.devices,
    required this.selectedDeviceId,
    required this.isScanning,
    required this.onSelect,
    required this.onScan,
  });

  final List<WatchDevice> devices;
  final String? selectedDeviceId;
  final bool isScanning;
  final ValueChanged<String> onSelect;
  final VoidCallback onScan;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22.r),
        border: AppBorders.raised(),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Nearby wearables',
                  style: AppTextStyles.montserrat(
                    size: 16.sp,
                    color: AppColors.textPrimary,
                    weight: FontWeight.w800,
                  ),
                ),
              ),
              TextButton(
                onPressed: isScanning ? null : onScan,
                child: Text(isScanning ? 'Scanning' : 'Scan'),
              ),
            ],
          ),
          8.verticalSpace,
          if (devices.isEmpty)
            Text(
              isScanning
                  ? 'Searching for Bluetooth devices...'
                  : 'No Bluetooth watch found. You can still sync from Apple Health or Health Connect.',
              style: AppTextStyles.montserrat(
                size: 12.sp,
                color: AppColors.textSecondary,
                weight: FontWeight.w500,
                height: 1.4,
              ),
            )
          else
            ...devices.map(
              (device) => _DeviceRow(
                device: device,
                selected: selectedDeviceId == device.id,
                onTap: () => onSelect(device.id),
              ),
            ),
        ],
      ),
    );
  }
}

class _DeviceRow extends StatelessWidget {
  const _DeviceRow({
    required this.device,
    required this.selected,
    required this.onTap,
  });

  final WatchDevice device;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14.r),
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8.h),
        child: Row(
          children: [
            Container(
              width: 36.w,
              height: 36.w,
              decoration: BoxDecoration(
                color: selected
                    ? const Color(0xFFEAF1FF)
                    : AppColors.scaffoldBackground,
                shape: BoxShape.circle,
              ),
              child: Icon(
                device.isLikelyWatch
                    ? Icons.watch_rounded
                    : Icons.bluetooth_rounded,
                size: 20.sp,
                color: selected ? AppColors.blueColor : AppColors.textSecondary,
              ),
            ),
            10.horizontalSpace,
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    device.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.montserrat(
                      size: 13.sp,
                      color: AppColors.textPrimary,
                      weight: FontWeight.w700,
                    ),
                  ),
                  2.verticalSpace,
                  Text(
                    device.isLikelyWatch
                        ? 'Wearable device'
                        : 'Bluetooth device',
                    style: AppTextStyles.montserrat(
                      size: 11.sp,
                      color: AppColors.textSecondary,
                      weight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              selected
                  ? Icons.radio_button_checked_rounded
                  : Icons.radio_button_off_rounded,
              size: 20.sp,
              color: selected ? AppColors.blueColor : AppColors.textSecondary,
            ),
          ],
        ),
      ),
    );
  }
}

class _SyncStatusList extends StatelessWidget {
  const _SyncStatusList({required this.stage});

  final WearableSyncStage stage;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22.r),
        border: AppBorders.raised(),
      ),
      child: Column(
        children: [
          _SyncStatusRow(
            label: 'Connecting Bluetooth device',
            complete: _isComplete(WearableSyncStage.connectingBluetooth),
            active: stage == WearableSyncStage.connectingBluetooth,
          ),
          14.verticalSpace,
          _SyncStatusRow(
            label: 'Requesting Health access',
            complete: _isComplete(WearableSyncStage.requestingAccess),
            active: stage == WearableSyncStage.requestingAccess,
          ),
          14.verticalSpace,
          _SyncStatusRow(
            label: 'Reading watch steps',
            complete: _isComplete(WearableSyncStage.readingSteps),
            active: stage == WearableSyncStage.readingSteps,
          ),
          14.verticalSpace,
          _SyncStatusRow(
            label: 'Updating dashboard',
            complete: _isComplete(WearableSyncStage.updatingDashboard),
            active: stage == WearableSyncStage.updatingDashboard,
          ),
        ],
      ),
    );
  }

  bool _isComplete(WearableSyncStage syncStage) {
    if (stage == WearableSyncStage.failed || stage == WearableSyncStage.idle) {
      return false;
    }
    if (stage == WearableSyncStage.connected) return true;
    return stage.index > syncStage.index;
  }
}

class _WearableErrorBanner extends StatelessWidget {
  const _WearableErrorBanner({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF1F2),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: const Color(0xFFFECACA), width: 1.w),
      ),
      child: Text(
        message,
        style: AppTextStyles.montserrat(
          size: 12.sp,
          color: const Color(0xFF991B1B),
          weight: FontWeight.w500,
        ),
      ),
    );
  }
}

class _SyncStatusRow extends StatelessWidget {
  const _SyncStatusRow({
    required this.label,
    required this.complete,
    this.active = false,
  });

  final String label;
  final bool complete;
  final bool active;

  @override
  Widget build(BuildContext context) {
    Widget leading;
    if (complete) {
      leading = Icon(
        Icons.check_circle_rounded,
        size: 20.sp,
        color: AppColors.success,
      );
    } else if (active) {
      leading = SizedBox(
        width: 20.sp,
        height: 20.sp,
        child: CircularProgressIndicator(
          strokeWidth: 2.5,
          valueColor: AlwaysStoppedAnimation<Color>(AppColors.blueColor),
        ),
      );
    } else {
      leading = Icon(
        Icons.radio_button_unchecked_rounded,
        size: 20.sp,
        color: AppColors.textSecondary,
      );
    }

    return Row(
      children: [
        leading,
        10.horizontalSpace,
        Expanded(
          child: Text(
            label,
            style: AppTextStyles.montserrat(
              size: 14.sp,
              color: active || complete
                  ? AppColors.textPrimary
                  : AppColors.textSecondary,
              weight: active ? FontWeight.w600 : FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }
}
