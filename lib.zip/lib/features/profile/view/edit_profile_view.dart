import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import 'package:test_steps/core/theme/app_colors.dart';
import 'package:test_steps/core/theme/app_text_styles.dart';
import 'package:test_steps/services/supabase_service.dart';
import 'package:test_steps/widgets/shared/app_circular_back_button.dart';
import 'package:test_steps/widgets/shared/app_text_input.dart';
import 'package:test_steps/widgets/shared/dashboard_segmented_tab_bar.dart';
import 'package:test_steps/widgets/shared/primary_button.dart';

class EditProfileView extends StatefulWidget {
  const EditProfileView({super.key});

  @override
  State<EditProfileView> createState() => _EditProfileViewState();
}

class _EditProfileViewState extends State<EditProfileView> {
  static const _displayNameKeys = ['display_name', 'full_name', 'name'];
  static const _locationKeys = ['location', 'city', 'region'];
  static const _birthdayKeys = ['birth_date', 'birthday', 'date_of_birth'];
  static const _bioKeys = ['bio', 'about', 'about_me'];
  static const _heightKeys = ['height_cm', 'height'];
  static const _weightKeys = ['weight_kg', 'weight'];
  static const _weightGoalKeys = ['weight_goal', 'goal'];
  static const _dailyGoalKeys = ['daily_steps_goal', 'step_goal'];

  final _service = SupabaseService();
  final _picker = ImagePicker();
  final _displayNameController = TextEditingController();
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  final _ageController = TextEditingController();
  final _locationController = TextEditingController();
  final _birthdayController = TextEditingController();
  final _bioController = TextEditingController();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  final _weightGoalController = TextEditingController();
  final _dailyGoalController = TextEditingController();

  final Set<String> _profileKeys = <String>{};
  bool _isLoading = true;
  bool _isSaving = false;
  String? _avatarUrl;
  Uint8List? _selectedAvatarBytes;
  String _selectedAvatarExt = 'jpg';
  String _selectedGender = 'Male';
  DateTime? _selectedBirthDate;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  @override
  void dispose() {
    _displayNameController.dispose();
    _usernameController.dispose();
    _emailController.dispose();
    _ageController.dispose();
    _locationController.dispose();
    _birthdayController.dispose();
    _bioController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    _weightGoalController.dispose();
    _dailyGoalController.dispose();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    setState(() => _isLoading = true);
    try {
      final profile = await _service.getProfile() ?? <String, dynamic>{};
      _profileKeys
        ..clear()
        ..addAll(profile.keys.map((e) => e.toString()));

      _avatarUrl = profile['avatar_url']?.toString();
      _usernameController.text =
          profile['username']?.toString() ??
          _service.currentUser?.email?.split('@').first ??
          '';
      _displayNameController.text = _readText(profile, _displayNameKeys);
      if (_displayNameController.text.trim().isEmpty) {
        _displayNameController.text = _usernameController.text;
      }
      _emailController.text = _service.currentUser?.email ?? '';
      _locationController.text = _readText(profile, _locationKeys);
      _bioController.text = _readText(profile, _bioKeys);
      _ageController.text = _formatAge(profile['age']);
      _heightController.text = _formatHeight(_readText(profile, _heightKeys));
      _weightController.text = _formatWeight(_readText(profile, _weightKeys));
      _weightGoalController.text = _formatGoal(
        _readText(profile, _weightGoalKeys),
      );
      _dailyGoalController.text = _formatDailyGoal(
        _readText(profile, _dailyGoalKeys),
      );
      _selectedGender = _formatGender(profile['gender']);

      final birthdayRaw = _readText(profile, _birthdayKeys);
      if (birthdayRaw.isNotEmpty) {
        final parsed = DateTime.tryParse(birthdayRaw);
        if (parsed != null) {
          _selectedBirthDate = parsed;
          _birthdayController.text = _formatDate(parsed);
          if (_ageController.text.isEmpty) {
            _ageController.text = _formatAge(_ageFromBirthDate(parsed));
          }
        } else {
          _birthdayController.text = birthdayRaw;
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to load profile: $e')));
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  String _readText(Map<String, dynamic> profile, List<String> keys) {
    for (final key in keys) {
      final value = profile[key];
      if (value != null && value.toString().trim().isNotEmpty) {
        return value.toString();
      }
    }
    return '';
  }

  String? _existingKey(List<String> keys) {
    for (final key in keys) {
      if (_profileKeys.contains(key)) return key;
    }
    return null;
  }

  String _formatDate(DateTime date) {
    final mm = date.month.toString().padLeft(2, '0');
    final dd = date.day.toString().padLeft(2, '0');
    return '${date.year}-$mm-$dd';
  }

  int _ageFromBirthDate(DateTime date) {
    final now = DateTime.now();
    var age = now.year - date.year;
    if (now.month < date.month ||
        (now.month == date.month && now.day < date.day)) {
      age -= 1;
    }
    return age;
  }

  String _formatAge(Object? value) {
    final age = _readNumber(value);
    return age == null ? '' : '${age.round()}y';
  }

  String _formatWeight(String value) {
    final number = _readNumber(value);
    if (number == null) return '';
    return '${_trimNumber(number)} kg';
  }

  String _formatHeight(String value) {
    final number = _readNumber(value);
    if (number == null) return '';
    return '${_trimNumber(number)} inches';
  }

  String _formatGoal(String value) {
    final trimmed = value.trim();
    return trimmed.isEmpty ? '' : 'Goal: $trimmed';
  }

  String _formatDailyGoal(String value) {
    final number = _readNumber(value);
    if (number == null) return '';
    return '${_formatInt(number.round())} Daily Goal';
  }

  String _formatGender(Object? value) {
    final gender = value?.toString().trim().toLowerCase();
    return gender == 'female' ? 'Female' : 'Male';
  }

  num? _readNumber(Object? value) {
    if (value is num) return value;
    final text = value?.toString() ?? '';
    final match = RegExp(r'-?\d+(?:[.,]\d+)?').firstMatch(text);
    if (match == null) return null;
    return num.tryParse(match.group(0)!.replaceAll(',', '.'));
  }

  String _trimNumber(num value) {
    if (value % 1 == 0) return value.round().toString();
    return value.toStringAsFixed(1);
  }

  String _formatInt(int value) {
    final text = value.toString();
    final buffer = StringBuffer();
    for (var index = 0; index < text.length; index++) {
      final remaining = text.length - index;
      buffer.write(text[index]);
      if (remaining > 1 && remaining % 3 == 1) buffer.write(',');
    }
    return buffer.toString();
  }

  String _stripGoalPrefix(String value) {
    return value.replaceFirst(RegExp(r'^goal:\s*', caseSensitive: false), '');
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final file = await _picker.pickImage(
        source: source,
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 88,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      final dot = file.name.lastIndexOf('.');
      final ext = dot >= 0 ? file.name.substring(dot + 1) : 'jpg';
      if (!mounted) return;
      setState(() {
        _selectedAvatarBytes = bytes;
        _selectedAvatarExt = ext.toLowerCase();
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not pick image: $e')));
    }
  }

  Future<void> _showImageSourceSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18.r)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.photo_library_outlined),
                  title: const Text('Choose from gallery'),
                  onTap: () async {
                    Navigator.of(context).pop();
                    await _pickImage(ImageSource.gallery);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.camera_alt_outlined),
                  title: const Text('Take a photo'),
                  onTap: () async {
                    Navigator.of(context).pop();
                    await _pickImage(ImageSource.camera);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _saveProfile() async {
    final displayName = _displayNameController.text.trim();
    final username = _usernameController.text.trim().isNotEmpty
        ? _usernameController.text.trim()
        : displayName;
    if (username.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Name is required')));
      return;
    }

    setState(() => _isSaving = true);
    try {
      var avatarUrl = _avatarUrl;
      if (_selectedAvatarBytes != null) {
        avatarUrl = await _service.uploadProfileAvatar(
          _selectedAvatarBytes!,
          fileExtension: _selectedAvatarExt,
        );
      }

      final updates = <String, dynamic>{'username': username};

      if (_profileKeys.contains('avatar_url') && avatarUrl != null) {
        updates['avatar_url'] = avatarUrl;
      }

      final displayNameKey = _existingKey(_displayNameKeys);
      if (displayNameKey != null) {
        updates[displayNameKey] = displayName.isEmpty ? null : displayName;
      }

      if (_profileKeys.contains('gender')) {
        updates['gender'] = _selectedGender;
      }

      if (_profileKeys.contains('age')) {
        updates['age'] = _readNumber(_ageController.text)?.round();
      }

      final locationKey = _existingKey(_locationKeys);
      if (locationKey != null) {
        final value = _locationController.text.trim();
        updates[locationKey] = value.isEmpty ? null : value;
      }

      final bioKey = _existingKey(_bioKeys);
      if (bioKey != null) {
        final value = _bioController.text.trim();
        updates[bioKey] = value.isEmpty ? null : value;
      }

      final birthdayKey = _existingKey(_birthdayKeys);
      if (birthdayKey != null) {
        updates[birthdayKey] = _selectedBirthDate
            ?.toIso8601String()
            .split('T')
            .first;
      }

      final heightKey = _existingKey(_heightKeys);
      if (heightKey != null) {
        final value = _heightController.text.trim();
        updates[heightKey] = value.isEmpty ? null : _readNumber(value);
      }

      final weightKey = _existingKey(_weightKeys);
      if (weightKey != null) {
        final value = _weightController.text.trim();
        updates[weightKey] = value.isEmpty ? null : _readNumber(value);
      }

      final weightGoalKey = _existingKey(_weightGoalKeys);
      if (weightGoalKey != null) {
        final value = _stripGoalPrefix(_weightGoalController.text).trim();
        updates[weightGoalKey] = value.isEmpty ? null : value;
      }

      final dailyGoalValue = _readNumber(_dailyGoalController.text)?.round();
      for (final dailyGoalKey in _dailyGoalKeys) {
        if (_profileKeys.contains(dailyGoalKey)) {
          updates[dailyGoalKey] = dailyGoalValue;
        }
      }

      await _service.updateProfile(updates);
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Profile updated')));
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to update profile: $e')));
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      body: Stack(
        children: [
          IgnorePointer(
            child: Image.asset(
              'assets/images/back.png',
              fit: BoxFit.cover,
              width: double.infinity,
              height: 250.h,
              color: AppColors.surface.withValues(alpha: 0.72),
            ),
          ),
          SafeArea(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: EdgeInsets.fromLTRB(16.w, 10.h, 16.w, 34.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _EditProfileHeader(
                          onAvatarTap: _showImageSourceSheet,
                          avatarUrl: _avatarUrl,
                          selectedAvatarBytes: _selectedAvatarBytes,
                        ),
                        34.verticalSpace,
                        AppTextInput(
                          controller: _displayNameController,
                          hintText: 'Name',
                          height: 49,
                        ),
                        18.verticalSpace,
                        AppTextInput(
                          controller: _emailController,
                          hintText: 'Email',
                          readOnly: true,
                          keyboardType: TextInputType.emailAddress,
                          height: 49,
                        ),
                        18.verticalSpace,
                        DashboardSegmentedTabBar(
                          labels: const ['Male', 'Female'],
                          selectedIndex: _selectedGender == 'Female' ? 1 : 0,
                          height: 43,
                          backgroundColor: AppColors.surface,
                          inactiveTextColor: AppColors.textNavy,
                          onChanged: (index) => setState(
                            () => _selectedGender = index == 1
                                ? 'Female'
                                : 'Male',
                          ),
                        ),
                        18.verticalSpace,
                        AppTextInput(
                          controller: _ageController,
                          hintText: 'Age',
                          keyboardType: TextInputType.number,
                          height: 49,
                        ),
                        18.verticalSpace,
                        Row(
                          children: [
                            Expanded(
                              child: AppTextInput(
                                controller: _weightController,
                                hintText: 'Weight',
                                keyboardType:
                                    const TextInputType.numberWithOptions(
                                      decimal: true,
                                    ),
                                height: 49,
                              ),
                            ),
                            18.horizontalSpace,
                            Expanded(
                              child: AppTextInput(
                                controller: _heightController,
                                hintText: 'Height',
                                keyboardType:
                                    const TextInputType.numberWithOptions(
                                      decimal: true,
                                    ),
                                height: 49,
                              ),
                            ),
                          ],
                        ),
                        18.verticalSpace,
                        AppTextInput(
                          controller: _weightGoalController,
                          hintText: 'Goal',
                          height: 49,
                        ),
                        18.verticalSpace,
                        AppTextInput(
                          controller: _dailyGoalController,
                          hintText: 'Daily Goal',
                          keyboardType: TextInputType.number,
                          height: 49,
                        ),
                        46.verticalSpace,
                        PrimaryButton(
                          label: _isSaving ? 'Saving...' : 'Save',
                          isLoading: _isSaving,
                          onTap: _isSaving ? null : _saveProfile,
                          verticalPadding: 15.h,
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _EditProfileHeader extends StatelessWidget {
  const _EditProfileHeader({
    required this.avatarUrl,
    required this.selectedAvatarBytes,
    required this.onAvatarTap,
  });

  final String? avatarUrl;
  final Uint8List? selectedAvatarBytes;
  final VoidCallback onAvatarTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 221.h,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          const Positioned(top: 0, left: 0, child: AppCircularBackButton()),
          Positioned(
            top: 9.h,
            left: 0,
            right: 0,
            child: Text(
              'Edit profile',
              textAlign: TextAlign.center,
              style: AppTextStyles.montserrat(
                size: 20.sp,
                color: AppColors.textPrimary,
                weight: FontWeight.w800,
              ),
            ),
          ),
          Positioned(
            top: 72.h,
            left: 0,
            right: 0,
            child: Center(
              child: GestureDetector(
                onTap: onAvatarTap,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 110.w,
                      height: 110.w,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.surface,
                        border: Border.all(color: AppColors.borderColor),
                      ),
                      child: ClipOval(
                        child: _AvatarContent(
                          avatarUrl: avatarUrl,
                          selectedAvatarBytes: selectedAvatarBytes,
                        ),
                      ),
                    ),
                    Positioned(
                      right: 2.w,
                      bottom: 3.h,
                      child: Container(
                        width: 34.w,
                        height: 34.w,
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.borderColor),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.textPrimary.withValues(
                                alpha: 0.08,
                              ),
                              blurRadius: 10.r,
                              offset: Offset(0, 3.h),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.manage_accounts_outlined,
                          size: 20.sp,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AvatarContent extends StatelessWidget {
  const _AvatarContent({
    required this.avatarUrl,
    required this.selectedAvatarBytes,
  });

  final String? avatarUrl;
  final Uint8List? selectedAvatarBytes;

  @override
  Widget build(BuildContext context) {
    if (selectedAvatarBytes != null) {
      return Image.memory(selectedAvatarBytes!, fit: BoxFit.cover);
    }
    if (avatarUrl != null && avatarUrl!.isNotEmpty) {
      return Image.network(
        avatarUrl!,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _fallback(),
      );
    }
    return _fallback();
  }

  Widget _fallback() {
    return Image.asset(
      'assets/images/profile.png',
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Icon(
        Icons.account_circle_outlined,
        size: 58.sp,
        color: AppColors.textSecondary,
      ),
    );
  }
}
