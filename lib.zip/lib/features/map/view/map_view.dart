import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:test_steps/features/map/widgets/attack_history_sheet.dart';
import 'package:test_steps/features/map/widgets/attack_toast.dart';
import 'package:test_steps/services/notification_service.dart';
import 'package:test_steps/features/map/widgets/exit_run_dialog.dart';
import 'package:test_steps/features/map/widgets/home_base_setup_sheet.dart';
import 'package:test_steps/features/map/widgets/map_top_controls.dart';
import 'package:test_steps/features/map/widgets/run_session_summary_panel.dart';
import 'package:test_steps/features/map/widgets/start_countdown_overlay.dart';
import 'package:test_steps/features/map/widgets/tile_info_sheet.dart';
import 'package:test_steps/models/map_model.dart';
import 'package:test_steps/models/walk_models.dart';
import 'package:test_steps/providers/map_provider.dart';
import 'package:test_steps/widgets/shared/map_view.dart';
import 'package:test_steps/widgets/shared/primary_button.dart';

class MapView extends ConsumerStatefulWidget {
  const MapView({super.key});

  @override
  ConsumerState<MapView> createState() => _MapViewState();
}

class _MapViewState extends ConsumerState<MapView>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  GoogleMapController? _mapController;
  final AttackToastController _attackToastController = AttackToastController();
  late final AnimationController _attackWarningController;
  StreamSubscription<NotificationEvent>? _notificationSub;
  final TextEditingController _homeBaseLocationController =
      TextEditingController();
  Timer? _homeBaseSearchDebounce;

  bool _showHomeBaseSetup = false;
  bool _isSettingHomeBase = false;
  bool _isSelectingHomeBaseLocation = false;
  bool _isSearchingHomeBaseLocation = false;
  bool _showStartTerritories = false;
  bool _showStartCountdown = false;
  bool _showExitRunDialog = false;
  bool _hasStarted = false;
  bool _isPaused = false;
  DateTime? _runStartedAt;
  DateTime? _runPausedAt;
  LatLng? _selectedHomeBaseCoordinates;
  List<HomeBaseLocationSuggestion> _homeBaseSuggestions = const [];
  String? _homeBaseSearchError;
  int _homeBaseSearchRequestId = 0;
  bool _hasCenteredOnUser = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _attackWarningController =
        AnimationController(
            vsync: this,
            duration: const Duration(milliseconds: 900),
          )
          ..addListener(() {
            if (mounted &&
                ref.read(mapProvider).underAttackTerritoryIds.isNotEmpty) {
              setState(() {});
            }
          })
          ..repeat();
    // Listen for in-app notifications and show attack toasts for territory events
    _notificationSub = NotificationService.notificationStream.listen((ev) {
      final variant = _variantForNotification(ev.type);
      if (variant != null) {
        final message = ev.body.isNotEmpty ? ev.body : ev.title;
        _attackToastController.show(variant, message);
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _notificationSub?.cancel();
    _attackWarningController.dispose();
    _attackToastController.dispose();
    _homeBaseSearchDebounce?.cancel();
    _homeBaseLocationController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if ((state == AppLifecycleState.inactive ||
            state == AppLifecycleState.paused ||
            state == AppLifecycleState.detached) &&
        ref.read(mapProvider).isRunActive) {
      ref.read(mapProvider.notifier).persistRunProgress();
    }
  }

  @override
  Widget build(BuildContext context) {
    final mapState = ref.watch(mapProvider);
    final currentUserId = ref.read(mapProvider.notifier).currentUser?.id;
    ref.listen<MapState>(mapProvider, (previous, next) {
      final userLocation = next.userLocation;
      if (!_hasCenteredOnUser &&
          userLocation != null &&
          previous?.userLocation != userLocation) {
        _centerMapOnUser(userLocation);
      }

      final result = next.lastAttackResult;
      if (result == null ||
          identical(previous?.lastAttackResult, next.lastAttackResult)) {
        return;
      }
      final action = result['action']?.toString() ?? 'error';
      final variant = AttackToastController.variantFromAction(action);
      if (variant != null) {
        _attackToastController.show(variant, _attackMessage(result));
      }
      if (_isTerritoryHistoryAction(action)) {
        ref.invalidate(attackHistoryProvider);
      }
    });

    return PopScope(
      canPop: !_hasStarted,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _hasStarted) {
          setState(() => _showExitRunDialog = true);
        }
      },
      child: Scaffold(
        body: SizedBox.expand(
          child: Stack(
            fit: StackFit.expand,
            children: [
              GoogleMapLayer(
                mapState: mapState,
                polygons: _buildClaimedTerritoryPolygons(
                  mapState,
                  currentUserId,
                ),
                onMapCreated: (controller) {
                  _mapController = controller;
                  final userLocation = ref.read(mapProvider).userLocation;
                  if (userLocation != null) {
                    _centerMapOnUser(userLocation);
                  }
                },
                onCameraIdle: () async {
                  final bounds = await _mapController?.getVisibleRegion();
                  if (bounds != null) {
                    ref
                        .read(mapProvider.notifier)
                        .loadTerritoriesForBounds(bounds);
                  }
                },
                onCameraMove: (_) {},
                onTap: (_) => _showTerritorySheet(null, currentUserId),
                buildPolylines: () => _buildRunPolylines(mapState),
              ),
              if (mapState.isLoading &&
                  mapState.userLocation == null &&
                  mapState.homeBase == null)
                const Positioned.fill(
                  child: ColoredBox(
                    color: Color(0xFFF3F6FA),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                ),
              MapTopControls(
                onBack: _handleMapBack,
                onLocate: () => _focusLocation(mapState),
              ),
              Positioned(
                left: 20,
                right: 20,
                bottom: 145,
                child: IgnorePointer(
                  child: AttackToastOverlay(controller: _attackToastController),
                ),
              ),
              if (!_hasStarted) _buildStartTerritoriesSheet(),
              if (_hasStarted && _runStartedAt != null)
                RunSessionSummaryPanel(
                  startedAt: _runStartedAt!,
                  pausedAt: _runPausedAt,
                  distanceKm: mapState.runDistanceKm,
                  steps: mapState.runSteps,
                  claimedAreaKm2: mapState.runClaimedAreaKm2,
                  isPaused: _isPaused,
                  onPause: _pauseRun,
                  onResume: _resumeRun,
                  onFinish: _finishRun,
                  onHistory: () => showAttackHistorySheet(
                    context,
                    attackEnergy: mapState.currentAttackEnergy,
                  ),
                ),
              if (_showHomeBaseSetup) ...[
                Positioned.fill(
                  child: GestureDetector(
                    onTap: () => setState(() => _showHomeBaseSetup = false),
                    child: Container(
                      color: Colors.black.withValues(alpha: 0.45),
                    ),
                  ),
                ),
                HomeBaseSetupSheet(
                  isLoading: _isSettingHomeBase,
                  isSelectingLocation: _isSelectingHomeBaseLocation,
                  isSearchingLocation: _isSearchingHomeBaseLocation,
                  locationController: _homeBaseLocationController,
                  suggestions: _homeBaseSuggestions,
                  searchError: _homeBaseSearchError,
                  onSuggestionSelected: _selectHomeBaseSuggestion,
                  onLocationChanged: _onHomeBaseLocationChanged,
                  onSearchLocation: _searchHomeBaseLocation,
                  onUseCurrentLocation: _selectCurrentLocation,
                  onSetHomeBase: _setHomeBase,
                ),
              ],
              if (_showStartCountdown)
                StartCountdownOverlay(
                  onComplete: _completeCountdown,
                  onCancel: _cancelCountdown,
                ),
              if (_showExitRunDialog) ...[
                Positioned.fill(
                  child: Container(color: Colors.black.withValues(alpha: 0.45)),
                ),
                ExitRunDialog(
                  onClose: () => setState(() => _showExitRunDialog = false),
                  onConfirmExit: _confirmFinishRun,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStartTerritoriesSheet() {
    final territories = _startSheetTerritories(
      ref.read(mapProvider),
      ref.read(mapProvider.notifier).currentUser?.id,
    );

    return NotificationListener<DraggableScrollableNotification>(
      onNotification: _handleStartSheetNotification,
      child: DraggableScrollableSheet(
        initialChildSize: 0.13,
        minChildSize: 0.13,
        maxChildSize: 0.92,
        snap: true,
        snapSizes: const [0.13, 0.92],
        builder: (context, scrollController) {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(24),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.10),
                  blurRadius: 24,
                  offset: const Offset(0, -8),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: CustomScrollView(
                controller: scrollController,
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 49,
                            height: 5,
                            margin: EdgeInsets.only(
                              bottom: _showStartTerritories ? 8 : 20,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFD9DCE4),
                              borderRadius: BorderRadius.circular(99),
                            ),
                          ),
                          if (!_showStartTerritories)
                            PrimaryButton(
                              label: 'Tap to Start',
                              onTap: _handleTapToStart,
                            ),
                        ],
                      ),
                    ),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
                    sliver: _showStartTerritories && territories.isEmpty
                        ? const SliverToBoxAdapter(
                            child: Padding(
                              padding: EdgeInsets.symmetric(vertical: 32),
                              child: Text(
                                'No claimed territories are visible here yet.',
                                textAlign: TextAlign.center,
                              ),
                            ),
                          )
                        : SliverList.separated(
                            itemBuilder: (context, index) {
                              return OwnedTerritoryInfoCard(
                                territory: territories[index],
                              );
                            },
                            separatorBuilder: (_, _) =>
                                const SizedBox(height: 14),
                            itemCount: _showStartTerritories
                                ? territories.length
                                : 0,
                          ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _selectCurrentLocation() async {
    if (_isSelectingHomeBaseLocation) return;
    setState(() => _isSelectingHomeBaseLocation = true);
    await ref.read(mapProvider.notifier).getCurrentLocation();
    if (!mounted) return;
    final mapState = ref.read(mapProvider);
    final location = mapState.userLocation;
    final error = mapState.error;

    setState(() {
      _isSelectingHomeBaseLocation = false;
      if (error == null && location != null) {
        _selectedHomeBaseCoordinates = location;
        _homeBaseSuggestions = const [];
        _homeBaseSearchError = null;
      }
    });

    if (error == null && location != null) {
      final address = await _addressForCoordinates(location);
      if (!mounted) return;
      _homeBaseLocationController.text = address;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(error ?? 'Current location selected.'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _searchHomeBaseLocation(String query) async {
    final trimmedQuery = query.trim();
    if (trimmedQuery.isEmpty || _isSearchingHomeBaseLocation) return;

    FocusScope.of(context).unfocus();
    await _loadHomeBaseSuggestions(trimmedQuery);
  }

  void _onHomeBaseLocationChanged(String query) {
    _selectedHomeBaseCoordinates = null;
    _homeBaseSearchDebounce?.cancel();

    final trimmedQuery = query.trim();
    if (trimmedQuery.length < 3) {
      setState(() {
        _homeBaseSuggestions = const [];
        _homeBaseSearchError = null;
        _isSearchingHomeBaseLocation = false;
      });
      return;
    }

    _homeBaseSearchDebounce = Timer(const Duration(milliseconds: 700), () {
      _loadHomeBaseSuggestions(trimmedQuery);
    });
  }

  Future<void> _loadHomeBaseSuggestions(String query) async {
    final requestId = ++_homeBaseSearchRequestId;
    setState(() {
      _isSearchingHomeBaseLocation = true;
      _homeBaseSearchError = null;
    });

    try {
      final results = await locationFromAddress(query);
      if (!mounted || requestId != _homeBaseSearchRequestId) return;
      if (results.isEmpty) {
        setState(() {
          _homeBaseSuggestions = const [];
          _homeBaseSearchError = 'No matching locations found.';
        });
        return;
      }

      final suggestions = await Future.wait(
        results.take(5).map((result) async {
          final coordinates = LatLng(result.latitude, result.longitude);
          final label = await _addressForCoordinates(
            coordinates,
            fallback: query,
          );
          return HomeBaseLocationSuggestion(
            label: label,
            latitude: result.latitude,
            longitude: result.longitude,
          );
        }),
      );
      if (!mounted || requestId != _homeBaseSearchRequestId) return;

      setState(() {
        _homeBaseSuggestions = suggestions;
        _homeBaseSearchError = null;
      });
    } catch (_) {
      if (mounted && requestId == _homeBaseSearchRequestId) {
        setState(() {
          _homeBaseSuggestions = const [];
          _homeBaseSearchError =
              'Search is unavailable. Try a city and full street address.';
        });
      }
    } finally {
      if (mounted && requestId == _homeBaseSearchRequestId) {
        setState(() => _isSearchingHomeBaseLocation = false);
      }
    }
  }

  void _selectHomeBaseSuggestion(HomeBaseLocationSuggestion suggestion) {
    final coordinates = LatLng(suggestion.latitude, suggestion.longitude);
    FocusScope.of(context).unfocus();
    setState(() {
      _selectedHomeBaseCoordinates = coordinates;
      _homeBaseSuggestions = const [];
      _homeBaseSearchError = null;
    });
    _homeBaseLocationController.text = suggestion.label;
    _mapController?.animateCamera(CameraUpdate.newLatLngZoom(coordinates, 15));
  }

  Future<String> _addressForCoordinates(
    LatLng coordinates, {
    String? fallback,
  }) async {
    try {
      final placemarks = await placemarkFromCoordinates(
        coordinates.latitude,
        coordinates.longitude,
      );
      if (placemarks.isNotEmpty) {
        final address = _formatPlacemark(placemarks.first);
        if (address.isNotEmpty) return address;
      }
    } catch (_) {}

    return fallback ??
        '${coordinates.latitude.toStringAsFixed(5)}, '
            '${coordinates.longitude.toStringAsFixed(5)}';
  }

  String _formatPlacemark(Placemark placemark) {
    final parts = <String?>[
      placemark.name,
      placemark.street,
      placemark.subLocality,
      placemark.locality,
      placemark.administrativeArea,
      placemark.country,
    ];
    final unique = <String>[];
    for (final part in parts) {
      final value = part?.trim();
      if (value != null && value.isNotEmpty && !unique.contains(value)) {
        unique.add(value);
      }
    }
    return unique.join(', ');
  }

  void _showLocationMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  bool _handleStartSheetNotification(
    DraggableScrollableNotification notification,
  ) {
    final shouldShow = notification.extent > 0.14;
    if (shouldShow == _showStartTerritories) return false;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && shouldShow != _showStartTerritories) {
        setState(() => _showStartTerritories = shouldShow);
      }
    });

    return false;
  }

  List<Territory> _startSheetTerritories(
    MapState mapState,
    String? currentUserId,
  ) {
    return _trackingSheetTerritories(mapState, currentUserId);
  }

  void _handleTapToStart() {
    final mapState = ref.read(mapProvider);
    if (mapState.isLoading) return;

    if (mapState.homeBase == null) {
      setState(() => _showHomeBaseSetup = true);
      return;
    }

    _beginCountdown();
  }

  Future<void> _setHomeBase() async {
    if (_isSettingHomeBase) return;
    final location = _selectedHomeBaseCoordinates;
    if (location == null) {
      _showLocationMessage('Select or search for a location first.');
      return;
    }
    setState(() => _isSettingHomeBase = true);
    final result = await ref.read(mapProvider.notifier).setHomeBase(location);
    if (!mounted) return;
    setState(() {
      _isSettingHomeBase = false;
      if (result['success'] == true) {
        _showHomeBaseSetup = false;
        _showStartCountdown = true;
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result['success'] == true
              ? 'Home base updated.'
              : result['error']?.toString() ?? 'Could not set home base.',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _beginCountdown() {
    setState(() {
      _showStartTerritories = false;
      _showStartCountdown = true;
    });
  }

  void _completeCountdown() {
    if (!mounted) return;
    setState(() => _showStartCountdown = false);
    _startRun();
  }

  void _cancelCountdown() {
    setState(() => _showStartCountdown = false);
  }

  Future<void> _startRun() async {
    setState(() {
      _hasStarted = true;
      _isPaused = false;
      _runStartedAt = DateTime.now();
      _runPausedAt = null;
    });
    await ref.read(mapProvider.notifier).startRun();
  }

  void _pauseRun() {
    ref.read(mapProvider.notifier).pauseRun();
    setState(() {
      _isPaused = true;
      _runPausedAt = DateTime.now();
    });
  }

  void _resumeRun() {
    ref.read(mapProvider.notifier).resumeRun();
    final pausedAt = _runPausedAt;
    if (pausedAt != null && _runStartedAt != null) {
      _runStartedAt = _runStartedAt!.add(DateTime.now().difference(pausedAt));
    }
    setState(() {
      _isPaused = false;
      _runPausedAt = null;
    });
  }

  void _finishRun() {
    setState(() => _showExitRunDialog = true);
  }

  void _handleMapBack() {
    if (_hasStarted) {
      setState(() => _showExitRunDialog = true);
      return;
    }
    Navigator.maybePop(context);
  }

  Future<void> _confirmFinishRun() async {
    await ref.read(mapProvider.notifier).finishRun();
    if (!mounted) return;
    setState(() {
      _showExitRunDialog = false;
      _hasStarted = false;
      _isPaused = false;
      _runStartedAt = null;
      _runPausedAt = null;
    });
  }

  Set<Polyline> _buildRunPolylines(MapState mapState) {
    if (mapState.runRoute.length < 2) return const {};
    return {
      Polyline(
        polylineId: const PolylineId('active_run'),
        points: mapState.runRoute,
        color: const Color(0xFF4169FF),
        width: 6,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        jointType: JointType.round,
      ),
    };
  }

  Set<Polygon> _buildClaimedTerritoryPolygons(
    MapState mapState,
    String? currentUserId,
  ) {
    final polygons = <Polygon>{};
    final warningPulse =
        (math.sin(_attackWarningController.value * math.pi * 2) + 1) / 2;
    final warningFillAlpha = 0.08 + (warningPulse * 0.16);
    final warningStrokeAlpha = 0.55 + (warningPulse * 0.45);
    final warningStrokeWidth = warningPulse > 0.5 ? 7 : 5;

    for (final territory in mapState.nearbyTerritories.where(
      (territory) => territory.userId.isNotEmpty && territory.hasPolygon,
    )) {
      final isMine = territory.userId == currentUserId;
      final baseColor = isMine
          ? const Color(0xFF4169FF)
          : _territoryColor(territory.color);
      final isProtected = territory.isProtected();
      final isUnderAttack = mapState.underAttackTerritoryIds.contains(
        territory.id,
      );

      polygons.add(
        Polygon(
          polygonId: PolygonId('claimed_${territory.id}'),
          points: territory.polygonPoints,
          fillColor: baseColor.withValues(alpha: isProtected ? 0.34 : 0.24),
          strokeColor: baseColor.withValues(alpha: 0.9),
          strokeWidth: isMine ? 3 : 2,
          consumeTapEvents: true,
          onTap: () => _showTerritorySheet(territory, currentUserId),
        ),
      );

      if (isUnderAttack) {
        polygons.add(
          Polygon(
            polygonId: PolygonId('under_attack_${territory.id}'),
            points: territory.polygonPoints,
            fillColor: const Color(
              0xFFFF2D2D,
            ).withValues(alpha: warningFillAlpha),
            strokeColor: const Color(
              0xFFFFA500,
            ).withValues(alpha: warningStrokeAlpha),
            strokeWidth: warningStrokeWidth,
            consumeTapEvents: true,
            onTap: () => _showTerritorySheet(territory, currentUserId),
          ),
        );
      }
    }

    return polygons;
  }

  Color _territoryColor(String value) {
    final hex = value.replaceFirst('#', '');
    final parsed = int.tryParse(hex.length == 6 ? 'FF$hex' : hex, radix: 16);
    return parsed == null ? const Color(0xFF7B6FD4) : Color(parsed);
  }

  void _focusLocation(MapState mapState) {
    final loc = mapState.userLocation ?? mapState.homeBase;
    if (loc != null) {
      _mapController?.animateCamera(CameraUpdate.newLatLngZoom(loc, 15));
    }
  }

  void _centerMapOnUser(LatLng location) {
    final controller = _mapController;
    if (controller == null) return;
    _hasCenteredOnUser = true;
    controller.animateCamera(CameraUpdate.newLatLngZoom(location, 15));
  }

  bool _isOwnTerritory(Territory territory, String? currentUserId) {
    return currentUserId != null && territory.userId == currentUserId;
  }

  List<Territory> _trackingSheetTerritories(
    MapState mapState,
    String? currentUserId,
  ) {
    return mapState.nearbyTerritories
        .where((territory) => _isOwnTerritory(territory, currentUserId))
        .toList();
  }

  void _showTerritorySheet(Territory? territory, String? currentUserId) {
    final cooldownUntil = territory?.cooldownUntil;
    if (cooldownUntil != null && cooldownUntil.isAfter(DateTime.now())) {
      _attackToastController.show(
        AttackToastVariant.cooldown,
        _cooldownRemainingLabel(cooldownUntil),
      );
    }

    showTileInfoSheet(
      context: context,
      tile: territory,
      currentUserId: currentUserId,
      toastController: _attackToastController,
    );
  }

  String _attackMessage(Map<String, dynamic> result) {
    final explicitMessage = result['message']?.toString();
    if (explicitMessage != null && explicitMessage.trim().isNotEmpty) {
      return explicitMessage;
    }

    switch (result['action']?.toString()) {
      case 'claimed':
        return 'Territory claimed.';
      case 'captured':
        return 'Enemy territory captured.';
      case 'damaged':
        final before =
            result['territory_energy_before'] ?? result['energy_before'] ?? '?';
        final after =
            result['territory_energy_after'] ?? result['energy_after'] ?? '?';
        return 'Territory damaged: $before to $after energy.';
      case 'reinforced':
        final after =
            result['territory_energy_after'] ?? result['energy_after'] ?? '?';
        return 'Territory reinforced to $after energy.';
      case 'protected':
      case 'shielded':
        return 'This territory is currently protected.';
      case 'cooldown':
        final minutes = int.tryParse(result['minutes_remaining'].toString());
        if (minutes != null && minutes > 0) {
          return '$minutes minutes remaining';
        }
        final rawUntil = result['cooldown_until'];
        final until = rawUntil == null ? null : DateTime.tryParse('$rawUntil');
        if (until != null) return _cooldownRemainingLabel(until);
        return 'Cooldown active';
      case 'no_energy':
        return 'No attack energy available.';
      default:
        return 'Territory action could not be completed.';
    }
  }

  String _cooldownRemainingLabel(DateTime cooldownUntil) {
    final remaining = cooldownUntil.difference(DateTime.now());
    if (remaining.isNegative) return 'Cooldown expired';
    final minutes = remaining.inMinutes;
    if (minutes >= 1) {
      return '$minutes ${minutes == 1 ? 'minute' : 'minutes'} remaining';
    }
    final seconds = remaining.inSeconds.clamp(0, 59);
    return '$seconds ${seconds == 1 ? 'second' : 'seconds'} remaining';
  }

  bool _isTerritoryHistoryAction(String action) {
    return action == 'claimed' ||
        action == 'captured' ||
        action == 'damaged' ||
        action == 'reinforced';
  }

  AttackToastVariant? _variantForNotification(String type) {
    switch (type) {
      case 'territory_under_attack':
        return AttackToastVariant.damaged;
      case 'territory_lost':
      case 'raid_victory':
        return AttackToastVariant.captured;
      case 'territory_defended':
      case 'territory_strengthened':
        return AttackToastVariant.reinforced;
      case 'rival_nearby':
      case 'cluster_created':
      case 'first_territory':
      case 'welcome':
        return AttackToastVariant.claimed;
      case 'raid_failed':
      case 'cluster_broken':
      case 'rival_dominating':
      case 'error':
        return AttackToastVariant.restricted;
      case 'spark':
      case 'raid_opportunity':
      case 'energy_full':
      case 'daily_summary':
      case 'season_results':
      case 'season_starting':
      case 'mid_season_reminder':
      case 'season_ending_soon':
      case 'streak_reminder':
      case 'daily_walk_reminder':
      case 'come_back':
      case 'join_circle_reminder':
        return AttackToastVariant.generic;
      case 'protected':
      case 'shielded':
        return AttackToastVariant.restricted;
      case 'cooldown':
        return AttackToastVariant.cooldown;
      case 'no_energy':
        return AttackToastVariant.noEnergy;
      default:
        return AttackToastVariant.generic;
    }
  }
}
