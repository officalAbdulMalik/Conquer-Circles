import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:test_steps/models/map_model.dart';

class GoogleMapLayer extends StatelessWidget {
  final MapState mapState;
  final void Function(GoogleMapController) onMapCreated;
  final VoidCallback onCameraIdle;
  final void Function(CameraPosition) onCameraMove;
  final Set<Polyline> Function() buildPolylines;
  final Set<Polygon> polygons;
  final void Function(LatLng position)? onTap;

  const GoogleMapLayer({
    super.key,
    required this.mapState,
    required this.onMapCreated,
    required this.onCameraIdle,
    required this.onCameraMove,
    required this.buildPolylines,
    this.polygons = const {},
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GoogleMap(
      initialCameraPosition: CameraPosition(
        target:
            mapState.userLocation ?? mapState.homeBase ?? const LatLng(0, 0),
        zoom: mapState.userLocation != null || mapState.homeBase != null
            ? 15.0
            : 2.0,
      ),

      myLocationEnabled: mapState.permissionGranted,
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false,
      polylines: buildPolylines(),
      polygons: polygons,
      onCameraIdle: onCameraIdle,
      onCameraMove: onCameraMove,
      onMapCreated: onMapCreated,
      onTap: onTap,
    );
  }
}
